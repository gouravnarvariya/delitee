import React from "react";
import { Link } from "react-router-dom";

const Breadcrumb = () => {
  return (
    <>
      <div className="home-top">
        <div className="page-title">
          <h3>Worker Detail</h3>
        </div>
      </div>
    </>
  );
};

export default Breadcrumb;
