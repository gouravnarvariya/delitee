const Breadcrumb = () => {
 
  return (
    <>
    <div className='home-top'>
        <div className='page-title'>
            <h3>My Profile</h3>
        </div>
    </div>
    </>
  )
}

export default Breadcrumb