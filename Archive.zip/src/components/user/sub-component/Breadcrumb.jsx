import React from 'react'

const Breadcrumb = () => {
  return (
    <>
    <div className='home-top'>
        <div className='page-title'>
            <h3>User List</h3>
        </div>
    </div>
    </>
  )
}

export default Breadcrumb