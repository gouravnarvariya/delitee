import React from 'react'

const Breadcrumb = () => {
  return (
    <>
    <div className='home-top'>
        <div className='page-title'>
            <h3>Change Password</h3>
        </div>
        {/* <div className='btns-evnts'>
              <div className='btns-evnts-inner'>
                <a href="btn primary-btn"></a>
              </div>
        </div> */}
    </div>
    </>
  )
}

export default Breadcrumb