import React, { useState } from 'react'
const Breadcrumb = () => {
 
  return (
    <>
    <div className='home-top'>
        <div className='page-title'>
            <h3>Quotation Detail</h3>
        </div>
    </div>
    </>
  )
}

export default Breadcrumb