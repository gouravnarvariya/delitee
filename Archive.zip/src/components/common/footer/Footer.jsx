import React from 'react'

const Footer = () => {
  return (
    <>
   
  <footer class="footer">
    <div class="cmpny-copyright">
      <p>Copyright © 2024 | All rights reserved</p>
      </div>
    </footer>
    </>
  )
}

export default Footer