export { default as Logo } from "./logo.png";
export { default as Product1 } from "./product-1.png";
export { default as UserImage } from "./user-image.jpg";
export { default as LoginBg } from "./login-bg.jpeg";
export { default as NotFoundImage } from "./not-found.svg";
export { default as service1 } from "./srvce1.png";
export { default as addIcon } from "./add-icon.png";
export { default as removeIcon } from "./remove-icon.png";
